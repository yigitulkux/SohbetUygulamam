// Pyracha: sadece kurulabilirlik icin; onbellek tutmaz, guncellemeleri engellemez.
self.addEventListener("install", function () { self.skipWaiting(); });
self.addEventListener("activate", function (e) { e.waitUntil(self.clients.claim()); });
self.addEventListener("fetch", function (e) {
  if (e.request.mode === "navigate") {
    e.respondWith(fetch(e.request).catch(function () {
      return new Response("Bağlantı yok. İnternetini kontrol edip tekrar dene.", { status: 503, headers: { "Content-Type": "text/plain; charset=utf-8" } });
    }));
  }
});
